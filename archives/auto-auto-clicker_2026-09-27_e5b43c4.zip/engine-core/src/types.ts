// Public type surface for engine-core.
//
// Content definitions (GearDefinition, EnemyDefinition) describe the game
// catalog and never live inside per-player save state. GameState is the only
// thing persisted, wrapped by the versioned SaveGame blob.

export type GearSlot = 'weapon' | 'ring1' | 'ring2' | 'necklace';

export interface GearDefinition {
  id: string;
  slot: GearSlot;
  dpsFactor: number;
  clickFactor: number;
  /**
   * Per-item-level growth factor. Gear stats are EXPONENTIAL in item level
   * (`floor(factor * gearGrowth^(itemLevel - 1))`), so gear drops supply the
   * exponential power term that tracks the exponential enemy-HP curve. This is
   * a content value, never persisted.
   */
  gearGrowth: number;
  upgradeCostBase: number;
  upgradeCostGrowth: number;
  upgradeStatMultiplier: number;
  dropChance: number;
  /**
   * Base effect contributions at item level 1. They scale by the SAME
   * `gearGrowth^(itemLevel - 1)` (and upgrade multiplier) as the weapon stats,
   * so a slot's effect tracks item level just like `dpsFactor`/`clickFactor`.
   * All four are 0 for slots that do not provide that effect; `critChance` and
   * `critMultiplier` come from rings, `goldMultiplier`/`powerMultiplier` from
   * the necklace.
   *
   * `critMultiplier` is a CONTRIBUTION to the critical-damage bonus: the total
   * critical multiplier is `1 + sum(contributions)`, so a contribution of 0.5
   * means critical hits deal 1.5x. A contribution of 0 therefore leaves the
   * total at the neutral 1x and cannot turn a crit into a penalty.
   */
  critChance: number;
  critMultiplier: number;
  goldMultiplier: number;
  powerMultiplier: number;
}

export interface EnemyDefinition {
  id: string;
  baseHp: number;
  hpGrowth: number;
  baseGold: number;
  goldGrowth: number;
  bossStageInterval: number;
  bossHpMultiplier: number;
  bossGoldMultiplier: number;
}

// SOURCE fields only. Battle stats (`dps`, `clickDamage`) are derived from
// `(definitionId, itemLevel, upgradeLevel)` via `computeGearStats` and are
// computed on read, never persisted.
export interface GearInstance {
  id: string;
  definitionId: string;
  itemLevel: number;
  upgradeLevel: number;
}

export interface PendingChoice {
  kind: 'boss-check' | 'progression-wall';
  stage: number;
  options: ('wait' | 'watchAd' | 'iap')[];
}

export interface GameState {
  meta: {
    saveVersion: number;
    seed: number;
    rngState: number;
    createdAt: number;
    totalPlayedMs: number;
    /**
     * Ids of unlocked achievements. Only ids are persisted; the catalog lives
     * in content-like static data (`achievements.ts`), never in save state.
     */
    achievements: string[];
  };
  // SOURCE fields only. The base auto/click stats are `BALANCE.baseAutoDps` /
  // `BALANCE.baseClickDamage`; the enemy's max HP is `enemyMaxHp(combat.stage)`.
  // All three are computed on read via `getEffectiveStats` / `getEnemyMaxHp`.
  player: {
    gold: number;
  };
  combat: {
    stage: number;
    enemyHp: number;
    damageCarry: number;
  };
  gear: {
    equipped: Record<GearSlot, GearInstance | null>;
    bag: GearInstance[];
    nextInstanceId: number;
  };
  choices: {
    pending: PendingChoice | null;
  };
}

export type Action =
  | { type: 'click' }
  | { type: 'equip'; instanceId: string }
  | { type: 'upgradeEquipped'; slot: GearSlot }
  | { type: 'resolveChoice'; choice: 'wait' | 'watchAd' | 'iap' };

export type GameEvent =
  | { type: 'stageEntered'; stage: number; isBoss: boolean; maxHp: number }
  | { type: 'damageDealt'; amount: number; source: 'auto' | 'click' }
  | { type: 'enemyKilled'; stage: number; gold: number; drops: GearInstance[] }
  | { type: 'gearEquipped'; instanceId: string }
  | { type: 'gearUpgraded'; instanceId: string; upgradeLevel: number; goldCost: number }
  | { type: 'goldChanged'; amount: number; total: number; reason: string }
  | { type: 'bossCheckFailed'; stage: number; projectedKillMs: number }
  | { type: 'progressionWall'; stage: number; projectedKillMs: number }
  | { type: 'choiceResolved'; choice: 'wait' | 'watchAd' | 'iap' }
  | { type: 'achievementUnlocked'; id: string; title: string };

export interface SaveGame {
  version: number;
  savedAt: number;
  state: GameState;
}
